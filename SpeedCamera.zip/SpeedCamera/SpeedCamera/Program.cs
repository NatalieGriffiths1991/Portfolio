﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpeedCamera
{
    class Program
    {
        /*Your job is to write a program for a speed camera. Write a program that asks the user to enter the speed limit. 
        Once set, the program asks for the speed of a car. 
        If the user enters a value less than the speed limit, program should display Ok on the console. 
        If the value is above the speed limit, the program should calculate the number of demerit points. 
        For every 5mph above the speed limit, 1 demerit points should be incurred and displayed on the console. 
        If the number of demerit points is above 12, the program should display License Suspended. */ 


        static void Main(string[] args)
        {
            int speedLimit; //Speed Limit 
            int carSpeed; //Speed of car
            
            Console.Title = "Speed Camera";
            Console.WriteLine("Please enter the speed limit in mph: ");
            speedLimit = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Please enter the car speed in mph: ");
            carSpeed = Convert.ToInt32(Console.ReadLine());

            if(carSpeed > speedLimit) //Speed limit broken
            {
                const int mphDemeritPoint = 5; 
                int demeritPoints = (carSpeed - speedLimit) / mphDemeritPoint;
                if(demeritPoints > 12)
                    {
                        Console.WriteLine("License Suspended!");
                    }
                 else
                     {
                        Console.WriteLine("Demerit Points: " + demeritPoints);
                     }
            }
            else //Speed limit kept to
            {
                Console.WriteLine("Ok");
            }
            Console.ReadKey();
        }
    }
}
